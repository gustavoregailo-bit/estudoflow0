# 📚 EstudoFlow

**Organizador de Estudos** — planeje sua rotina diária, mensal e anual de forma simples e visual.

Aplicativo web 100% front-end (HTML + CSS + JavaScript), sem necessidade de backend ou instalação. Os dados ficam salvos no navegador (localStorage).

---

## ✨ Funcionalidades

| Módulo | Descrição |
|--------|-----------|
| **Início (Dashboard)** | Resumo do dia, tarefas de hoje, progresso e metas próximas |
| **Diário** | Planejamento diário com filtros por matéria e status |
| **Mensal** | Calendário interativo com marcação dos dias que possuem tarefas |
| **Metas Anuais** | Objetivos de longo prazo com barra de progresso |
| **Matérias** | Cadastro de disciplinas com cor personalizada e meta de horas/semana |

### Recursos extras
- Tarefas com prioridade (baixa / média / alta), horário, duração e notas
- Marcar tarefas como concluídas (atualiza o progresso do dia automaticamente)
- Dados persistidos no navegador (não se perdem ao fechar a página)
- Interface responsiva (funciona bem no celular e no computador)
- Design moderno e limpo

---

## 🚀 Como usar

### Opção 1 — Abrir direto no navegador
1. Baixe ou clone este repositório
2. Abra o arquivo `index.html` no navegador (Chrome, Edge, Firefox…)

### Opção 2 — Com Live Server (recomendado no VS Code)
1. Abra a pasta do projeto no VS Code
2. Instale a extensão **Live Server**
3. Clique com o botão direito em `index.html` → **Open with Live Server**

### Opção 3 — GitHub Pages
1. Vá em **Settings → Pages**
2. Em *Source*, escolha a branch `main` e a pasta `/ (root)`
3. Salve. Em alguns minutos o site estará no ar em:
   `https://SEU-USUARIO.github.io/estudoflow`

---

## 📁 Estrutura do projeto

```
estudoflow/
├── index.html      # Estrutura da página
├── style.css       # Estilos e design
├── script.js       # Lógica e funcionalidades
├── README.md       # Este arquivo
└── .gitignore
```

---

## 🛠️ Tecnologias

- HTML5
- CSS3 (Flexbox + Grid + variáveis CSS)
- JavaScript (Vanilla) — sem frameworks
- Google Fonts (Inter + Poppins)
- localStorage para persistência dos dados

---

## 📱 Responsividade

O layout se adapta automaticamente a telas menores (tablets e celulares). No mobile a barra lateral vira um menu hambúrguer.

---

## 💾 Sobre os dados

Todos os dados (tarefas, metas e matérias) são salvos **localmente** no seu navegador.  
Eles não são enviados para nenhum servidor.  
Se limpar o cache do navegador, os dados serão apagados.

---

## 📄 Licença

Este projeto é de uso livre para fins educacionais e pessoais.

---

Feito com ❤️ para ajudar nos estudos.
